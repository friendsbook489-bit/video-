package com.medul.downloader

object DevInfo {
    const val NAME = "Md Medul"
    const val ROLE = "App Developer"
    const val VERSION = "1.0"
    // নিজের তথ্য এখানে বদলে নিন
    const val EMAIL = "your-email@example.com"
    const val GITHUB = "https://github.com/your-username"
}
