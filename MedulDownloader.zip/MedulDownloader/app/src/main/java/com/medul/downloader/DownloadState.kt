package com.medul.downloader

import kotlinx.coroutines.flow.MutableStateFlow

data class DlItem(
    val id: Int,
    val title: String,
    val audio: Boolean,
    val quality: Int,
    val progress: Float = 0f,
    val status: String = "Running"   // Running / Done / Failed
)

object DownloadState {
    val items = MutableStateFlow<List<DlItem>>(emptyList())

    fun upsert(item: DlItem) {
        val list = items.value.toMutableList()
        val i = list.indexOfFirst { it.id == item.id }
        if (i >= 0) list[i] = item else list.add(0, item)
        items.value = list
    }

    fun clearFinished() { items.value = items.value.filter { it.status == "Running" } }
}
