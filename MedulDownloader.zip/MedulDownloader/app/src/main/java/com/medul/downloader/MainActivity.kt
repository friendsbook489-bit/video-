package com.medul.downloader

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { Home() } } }
    }
}

@Composable
fun Home() {
    val ctx = LocalContext.current
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) { perm.launch(Manifest.permission.POST_NOTIFICATIONS) }
    val list by DownloadState.items.collectAsState()
    val scope = rememberCoroutineScope()
    var engineVer by remember { mutableStateOf(Engine.version(ctx)) }
    var engineMsg by remember { mutableStateOf("") }
    var updating by remember { mutableStateOf(false) }
    fun open(u: String) = ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Box(
                Modifier.size(110.dp).clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF6C3BFF), Color(0xFFFF3D8B)))),
                Alignment.Center
            ) {
                Icon(painterResource(R.drawable.ic_fg), null, Modifier.fillMaxSize(), tint = Color.Unspecified)
            }
        }
        item {
            Text("Medul Downloader", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Version ${DevInfo.VERSION}", style = MaterialTheme.typography.bodySmall)
        }
        item {
            Text("যেকোনো অ্যাপে ভিডিওর Share চাপুন, তালিকা থেকে \"Medul Downloader\" বেছে কোয়ালিটি সিলেক্ট করে ডাউনলোড করুন।",
                textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
        }
        item {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Running Downloads", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (list.any { it.status != "Running" })
                    TextButton({ DownloadState.clearFinished() }) { Text("Clear") }
            }
        }
        if (list.isEmpty()) {
            item { Text("এখন কোনো ডাউনলোড চলছে না", style = MaterialTheme.typography.bodySmall) }
        } else {
            items(list, key = { it.id }) { d -> DownloadRow(d) }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Engine (yt-dlp): $engineVer", style = MaterialTheme.typography.bodyMedium)
                    if (engineMsg.isNotEmpty()) Text(engineMsg, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(6.dp))
                    Button(enabled = !updating, onClick = {
                        updating = true; engineMsg = "আপডেট হচ্ছে..."
                        scope.launch {
                            val r = withContext(Dispatchers.IO) { Engine.update(ctx) }
                            engineVer = Engine.version(ctx)
                            engineMsg = if (r == "OK") "আপডেট সম্পন্ন ✔" else r.take(120)
                            updating = false
                        }
                    }) { Text("Update engine") }
                    Text("Facebook/TikTok এ এরর এলে এটা চাপুন", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Developer", style = MaterialTheme.typography.labelMedium)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(DevInfo.NAME, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(6.dp))
                        Icon(Icons.Filled.Verified, "verified", tint = MaterialTheme.colorScheme.primary)
                    }
                    Text(DevInfo.ROLE)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton({ open("mailto:${DevInfo.EMAIL}") }) { Text("Email") }
                        OutlinedButton({ open(DevInfo.GITHUB) }) { Text("GitHub") }
                    }
                }
            }
        }
        item {
            Text("শুধু নিজের বা অনুমতিপ্রাপ্ত কনটেন্ট ডাউনলোড করুন। কপিরাইট মেনে চলা ব্যবহারকারীর দায়িত্ব।",
                style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            Text("© Developed by ${DevInfo.NAME}", style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun DownloadRow(d: DlItem) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(d.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(if (d.audio) "Audio • ${d.quality} kbps" else "Video • ${d.quality}p",
                style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(8.dp))
            when (d.status) {
                "Running" -> {
                    LinearProgressIndicator(progress = { d.progress / 100f }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(4.dp))
                    Text("Running download ${d.progress.toInt()}%", style = MaterialTheme.typography.bodySmall)
                }
                "Done" -> Text("✔ Download complete (Movies/Music → MedulDownloader)",
                    color = Color(0xFF2E7D32), style = MaterialTheme.typography.bodySmall)
                else -> Text("✖ Download failed", color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
