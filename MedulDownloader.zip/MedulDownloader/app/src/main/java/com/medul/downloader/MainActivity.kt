package com.medul.downloader

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { About() } } }
    }
}

@Composable
fun About() {
    val ctx = LocalContext.current
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) { perm.launch(Manifest.permission.POST_NOTIFICATIONS) }
    fun open(u: String) = ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))

    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Box(Modifier.size(96.dp).clip(CircleShape).background(Color(0xFF6C3BFF)), Alignment.Center) {
            Icon(Icons.Filled.Download, null, Modifier.size(52.dp), tint = Color.White)
        }
        Spacer(Modifier.height(16.dp))
        Text("Medul Downloader", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Version ${DevInfo.VERSION}", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(20.dp))
        Text("যেকোনো সোশ্যাল মিডিয়া অ্যাপ থেকে ভিডিওর Share বাটনে চাপুন, তারপর তালিকা থেকে " +
            "\"Medul Downloader\" বেছে নিন। কোয়ালিটি সিলেক্ট করে সরাসরি ডাউনলোড করুন।",
            textAlign = TextAlign.Center)
        Spacer(Modifier.height(28.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Developer", style = MaterialTheme.typography.labelMedium)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(DevInfo.NAME, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.Filled.Verified, "verified", tint = MaterialTheme.colorScheme.primary)
                }
                Text(DevInfo.ROLE)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({ open("mailto:${DevInfo.EMAIL}") }) { Text("Email") }
                    OutlinedButton({ open(DevInfo.GITHUB) }) { Text("GitHub") }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("শুধু নিজের বা অনুমতিপ্রাপ্ত কনটেন্ট ডাউনলোড করুন। কপিরাইট আইন মেনে চলা ব্যবহারকারীর দায়িত্ব।",
            style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text("© Developed by ${DevInfo.NAME}", style = MaterialTheme.typography.labelSmall)
    }
}
