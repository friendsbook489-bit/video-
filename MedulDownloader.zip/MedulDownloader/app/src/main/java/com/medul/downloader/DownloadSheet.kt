package com.medul.downloader

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.mapper.VideoInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DownloadSheet(url: String, onClose: () -> Unit, onDownload: (audio: Boolean, quality: Int, title: String) -> Unit) {
    var info by remember { mutableStateOf<VideoInfo?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    var vq by remember { mutableIntStateOf(720) }
    var aq by remember { mutableIntStateOf(192) }

    val ctx = LocalContext.current
    var msg by remember { mutableStateOf("ভিডিওর তথ্য আনা হচ্ছে...") }

    LaunchedEffect(url) {
        try {
            info = withContext(Dispatchers.IO) { YoutubeDL.getInstance().getInfo(url) }
        } catch (e: Exception) {
            // ব্যর্থ হলে ইঞ্জিন আপডেট করে আবার চেষ্টা
            msg = "ইঞ্জিন আপডেট হচ্ছে, একটু অপেক্ষা করুন..."
            val st = withContext(Dispatchers.IO) { Engine.update(ctx) }
            msg = "আবার চেষ্টা করা হচ্ছে..."
            try {
                info = withContext(Dispatchers.IO) { YoutubeDL.getInstance().getInfo(url) }
            } catch (e2: Exception) {
                error = (e2.message ?: "Unknown error").take(300) +
                    (if (st != "OK") "\n(Engine update: $st)" else "")
            }
        }
    }

    ModalBottomSheet(onDismissRequest = onClose) {
        Column(Modifier.padding(16.dp).navigationBarsPadding()) {
            val i = info
            when {
                error != null -> Text("Error: $error", color = MaterialTheme.colorScheme.error)
                i == null -> Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(12.dp))
                    Text(msg, style = MaterialTheme.typography.bodySmall)
                }
                else -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(i.thumbnail, null, Modifier.size(110.dp, 70.dp).clip(RoundedCornerShape(10.dp)),
                            contentScale = ContentScale.Crop)
                        Spacer(Modifier.width(12.dp))
                        Text(i.title ?: "", maxLines = 3, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.titleSmall)
                    }
                    Spacer(Modifier.height(12.dp))
                    TabRow(tab) {
                        Tab(tab == 0, { tab = 0 }) { Text("Video", Modifier.padding(12.dp)) }
                        Tab(tab == 1, { tab = 1 }) { Text("Audio", Modifier.padding(12.dp)) }
                    }
                    Spacer(Modifier.height(12.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (tab == 0) listOf(360, 480, 720, 1080).forEach {
                            FilterChip(vq == it, { vq = it }, { Text("${it}p") })
                        } else listOf(64, 128, 192, 320).forEach {
                            FilterChip(aq == it, { aq = it }, { Text("$it kbps") })
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Button({ onDownload(tab == 1, if (tab == 0) vq else aq, i.title ?: "Video") }, Modifier.fillMaxWidth()) {
                        Text("Download")
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), Arrangement.Center, Alignment.CenterVertically) {
                Text("Developed by ${DevInfo.NAME}", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.width(4.dp))
                Icon(Icons.Filled.Verified, "verified", Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
