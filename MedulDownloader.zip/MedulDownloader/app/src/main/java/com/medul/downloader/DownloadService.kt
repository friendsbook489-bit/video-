package com.medul.downloader

import android.app.*
import android.content.*
import android.os.*
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.*
import java.io.File
import java.util.concurrent.atomic.AtomicInteger

class DownloadService : Service() {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val active = AtomicInteger(0)
    private val chId = "dl"

    companion object { private val counter = AtomicInteger(10) }

    override fun onBind(i: Intent?): IBinder? = null

    private fun open() = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
    )

    private fun notif(title: String, text: String, p: Int = -1, done: Boolean = false): Notification =
        NotificationCompat.Builder(this, chId)
            .setSmallIcon(if (done) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_sys_download)
            .setContentTitle(title).setContentText(text)
            .setContentIntent(open()).setOnlyAlertOnce(true)
            .setOngoing(!done).setAutoCancel(done)
            .apply { if (!done) setProgress(100, p.coerceAtLeast(0), p < 0) }
            .build()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val url = intent?.getStringExtra("url") ?: return START_NOT_STICKY
        val audio = intent.getBooleanExtra("audio", false)
        val q = intent.getIntExtra("q", 720)
        val title = intent.getStringExtra("title") ?: "Video"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(chId, "Downloads", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, notif("Medul Downloader", "Running download..."))

        val id = counter.incrementAndGet()
        active.incrementAndGet()
        DownloadState.upsert(DlItem(id, title, audio, q))

        scope.launch {
            try {
                val dir = File(cacheDir, "dl/$id").apply { deleteRecursively(); mkdirs() }
                val req = YoutubeDLRequest(url).apply {
                    if (audio) {
                        addOption("-x"); addOption("--audio-format", "mp3"); addOption("--audio-quality", "${q}K")
                    } else {
                        addOption("-f", "bv*[height<=$q]+ba/b[height<=$q]/b")
                        addOption("--merge-output-format", "mp4")
                    }
                    addOption("-o", "${dir.absolutePath}/%(title).80s.%(ext)s")
                }
                YoutubeDL.getInstance().execute(req) { p, _, _ ->
                    DownloadState.upsert(DlItem(id, title, audio, q, p.coerceIn(0f, 100f), "Running"))
                    nm.notify(id, notif(title, "Running download ${p.toInt()}%", p.toInt()))
                }
                val file = dir.listFiles()?.maxByOrNull { it.lastModified() } ?: error("No file")
                save(file, audio)
                DownloadState.upsert(DlItem(id, title, audio, q, 100f, "Done"))
                nm.notify(id, notif(title, "Download complete", 100, true))
            } catch (e: Exception) {
                DownloadState.upsert(DlItem(id, title, audio, q, 0f, "Failed"))
                nm.notify(id, notif(title, "Failed: ${e.message?.take(80)}", 0, true))
            } finally {
                if (active.decrementAndGet() == 0) {
                    stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun save(file: File, audio: Boolean) {
        val folder = (if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES) + "/MedulDownloader"
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, if (audio) "audio/mpeg" else "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
        }
        val coll = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val uri = contentResolver.insert(coll, v)!!
        contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
        file.delete()
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
