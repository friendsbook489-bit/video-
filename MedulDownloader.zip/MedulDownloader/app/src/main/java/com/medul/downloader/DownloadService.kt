package com.medul.downloader

import android.app.*
import android.content.*
import android.os.*
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.*
import java.io.File

class DownloadService : Service() {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val chId = "dl"

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val url = intent?.getStringExtra("url") ?: return START_NOT_STICKY
        val audio = intent.getBooleanExtra("audio", false)
        val q = intent.getIntExtra("q", 720)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(chId, "Downloads", NotificationManager.IMPORTANCE_LOW))
        fun notif(text: String, p: Int = -1, done: Boolean = false) = NotificationCompat.Builder(this, chId)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Medul Downloader").setContentText(text)
            .setOngoing(!done).setProgress(if (done) 0 else 100, p.coerceAtLeast(0), p < 0 && !done).build()
        startForeground(1, notif("Starting..."))

        scope.launch {
            try {
                val dir = File(cacheDir, "dl").apply { deleteRecursively(); mkdirs() }
                val req = YoutubeDLRequest(url).apply {
                    if (audio) {
                        addOption("-x"); addOption("--audio-format", "mp3"); addOption("--audio-quality", "${q}K")
                    } else {
                        addOption("-f", "bv*[height<=$q]+ba/b[height<=$q]/b")
                        addOption("--merge-output-format", "mp4")
                    }
                    addOption("-o", "${dir.absolutePath}/%(title).80s.%(ext)s")
                }
                YoutubeDL.getInstance().execute(req) { p, _, _ ->
                    nm.notify(1, notif("Downloading ${p.toInt()}%", p.toInt()))
                }
                val file = dir.listFiles()?.maxByOrNull { it.lastModified() } ?: error("No file")
                val name = file.name
                save(file, audio)
                nm.notify(1, notif("Download complete: $name", 100, true))
            } catch (e: Exception) {
                nm.notify(1, notif("Failed: ${e.message?.take(80)}", 0, true))
            } finally {
                stopForeground(STOP_FOREGROUND_DETACH); stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun save(file: File, audio: Boolean) {
        val folder = (if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES) + "/MedulDownloader"
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, if (audio) "audio/mpeg" else "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
        }
        val coll = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val uri = contentResolver.insert(coll, v)!!
        contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
        file.delete()
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
