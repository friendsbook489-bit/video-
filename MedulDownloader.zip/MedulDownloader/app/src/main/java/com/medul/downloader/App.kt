package com.medul.downloader

import android.app.Application
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            YoutubeDL.getInstance().init(this)
            FFmpeg.getInstance().init(this)
        } catch (e: Exception) { e.printStackTrace() }

        // প্রতি ৬ ঘণ্টায় একবার ব্যাকগ্রাউন্ডে ইঞ্জিন আপডেট
        val p = getSharedPreferences("engine", MODE_PRIVATE)
        if (System.currentTimeMillis() - p.getLong("last", 0L) > 6 * 3600_000L) {
            Thread {
                if (Engine.update(this) == "OK")
                    p.edit().putLong("last", System.currentTimeMillis()).apply()
            }.start()
        }
    }
}
