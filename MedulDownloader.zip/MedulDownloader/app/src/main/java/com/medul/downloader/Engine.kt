package com.medul.downloader

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDL

/** yt-dlp ইঞ্জিন আপডেট (Facebook/TikTok ইত্যাদি সাইট বদলালে এটাই ঠিক করে) */
object Engine {
    private val lock = Any()

    fun update(ctx: Context): String = synchronized(lock) {
        val app = ctx.applicationContext
        try {
            YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.NIGHTLY)
            "OK"
        } catch (e: Exception) {
            try {
                YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.STABLE)
                "OK"
            } catch (e2: Exception) {
                "ERR: ${e2.message}"
            }
        }
    }

    fun version(ctx: Context): String = try {
        YoutubeDL.getInstance().versionName(ctx.applicationContext) ?: "unknown"
    } catch (e: Exception) { "unknown" }
}
