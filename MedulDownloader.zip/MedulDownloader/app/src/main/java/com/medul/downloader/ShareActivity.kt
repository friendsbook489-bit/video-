package com.medul.downloader

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme

class ShareActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = intent.getStringExtra(Intent.EXTRA_TEXT)
        val url = text?.let { Regex("https?://\\S+").find(it)?.value }
        if (url == null) { finish(); return }
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
            .launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            MaterialTheme {
                DownloadSheet(url, onClose = { finish() }) { audio, q, title ->
                    startForegroundService(
                        Intent(this, DownloadService::class.java)
                            .putExtra("url", url).putExtra("audio", audio)
                            .putExtra("q", q).putExtra("title", title)
                    )
                    Toast.makeText(this, "Download শুরু হয়েছে", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
    }
}
