package com.medul.downloader

import android.Manifest
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme

class ShareActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return finish()
        val url = Regex("https?://\\S+").find(text)?.value ?: return finish()
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
            .launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            MaterialTheme {
                DownloadSheet(url, onClose = { finish() }) { audio, q ->
                    startForegroundService(Intent(this, DownloadService::class.java)
                        .putExtra("url", url).putExtra("audio", audio).putExtra("q", q))
                    finish()
                }
            }
        }
    }
}
