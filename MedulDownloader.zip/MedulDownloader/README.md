# Medul Downloader
Social media video/audio downloader (Android, Kotlin + Compose, yt-dlp engine).
Developer: Md Medul

## APK বানানোর নিয়ম
1. GitHub repository তে শুধু MedulDownloader.zip আপলোড করুন (খুলবেন না)।
2. `.github/workflows/build.yml` ফাইলটি আলাদাভাবে তৈরি করুন।
3. Actions -> Build APK from ZIP -> শেষে Artifacts থেকে APK নামান।
4. `DevInfo.kt` এ নিজের ইমেইল ও GitHub লিংক বসান।
