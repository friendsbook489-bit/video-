# Medul Downloader
Social media video/audio downloader (Android, Kotlin + Compose, yt-dlp engine).
Developer: Md Medul

## APK বানানোর নিয়ম
1. GitHub এ নতুন repository খুলে এই ফোল্ডারের সব ফাইল আপলোড করুন।
2. Actions ট্যাব -> Build APK -> শেষ হলে Artifacts থেকে APK নামান।
3. `DevInfo.kt` ফাইলে নিজের ইমেইল ও GitHub লিংক বসান।
